package com.reset.habittracker;

import android.app.*;
import android.content.*;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String title = intent.getStringExtra("title");
        if (title == null || title.trim().isEmpty()) title = "Time for your habit";
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(context, "reset_reminders")
            : new Notification.Builder(context);
        b.setSmallIcon(android.R.drawable.ic_popup_reminder)
         .setContentTitle("Reset reminder")
         .setContentText(title)
         .setAutoCancel(true)
         .setPriority(Notification.PRIORITY_DEFAULT);
        NotificationManager nm = (NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(title.hashCode(), b.build());
    }
}
