package com.reset.habittracker;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.*;
import android.widget.Toast;
import androidx.annotation.NonNull;

public class MainActivity extends Activity {
    private WebView web;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(248,247,244));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(248,247,244));
        getWindow().getDecorView().setSystemUiVisibility(ViewFlags());
        createChannel();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 41);
        web = new WebView(this);
        web.setBackgroundColor(android.graphics.Color.rgb(248,247,244));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        web.addJavascriptInterface(new ReminderBridge(this), "AndroidReminders");
        web.setWebViewClient(new WebViewClient());
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    private int ViewFlags() {
        return android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
    }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel("reset_reminders", "Habit reminders", NotificationManager.IMPORTANCE_DEFAULT);
            c.setDescription("Daily reminders for your habits");
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }
    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
    public static class ReminderBridge {
        private final MainActivity a;
        ReminderBridge(MainActivity activity) { a = activity; }
        @JavascriptInterface public void schedule(String id, String title, String time) {
            try {
                String[] p = time.split(":");
                int hour = Integer.parseInt(p[0]), minute = Integer.parseInt(p[1]);
                Intent i = new Intent(a, ReminderReceiver.class);
                i.putExtra("title", title);
                int request = id.hashCode() & 0x7fffffff;
                PendingIntent pi = PendingIntent.getBroadcast(a, request, i,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                java.util.Calendar c = java.util.Calendar.getInstance();
                c.set(java.util.Calendar.HOUR_OF_DAY, hour);
                c.set(java.util.Calendar.MINUTE, minute);
                c.set(java.util.Calendar.SECOND, 0);
                c.set(java.util.Calendar.MILLISECOND, 0);
                if (c.getTimeInMillis() <= System.currentTimeMillis()) c.add(java.util.Calendar.DAY_OF_YEAR, 1);
                AlarmManager am = (AlarmManager)a.getSystemService(ALARM_SERVICE);
                am.setInexactRepeating(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pi);
            } catch (Exception e) { }
        }
        @JavascriptInterface public void cancel(String id) {
            Intent i = new Intent(a, ReminderReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(a, id.hashCode() & 0x7fffffff, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            ((AlarmManager)a.getSystemService(ALARM_SERVICE)).cancel(pi);
            pi.cancel();
        }
    }
}
