# Reset — Android app project

This is an offline Android wrapper containing the Reset habit tracker UI and data locally on the device. It does not load the old AppDeploy website.

## Features
- Add and delete custom habits with emoji
- Current streak day count and reset count
- Monthly calendar with streak dates highlighted and month navigation
- Daily on-device reminders scheduled through Android AlarmManager
- Local device storage; no account or network required

## Build the APK from an Android phone using GitHub Actions
1. Download this ZIP and extract it on your phone.
2. In Chrome, create a new repository at https://github.com/new (sign in or create a free GitHub account). Name it `reset-android` and create it.
3. Open the new repository, choose **Add file → Upload files**, and upload the *contents* of this extracted folder (including the `.github` folder). Commit to `main`.
4. Open the repository's **Actions** tab. Select **Build Reset APK** and tap **Run workflow** if it has not started automatically.
5. Wait for the workflow to finish successfully. Open its run, scroll to **Artifacts**, and download `Reset-Android-APK`.
6. Open the downloaded ZIP, extract `app-debug.apk`, tap it, and allow Chrome or Files to install unknown apps if Android asks.

## Compatibility
- Minimum Android version: Android 10 (API 29)
- Debug APK is suitable for personal installation/testing. It is not Play Store signed.
- Daily reminders use Android's inexact repeating alarm scheduling; Android battery settings may affect exact delivery time. Allow notifications when prompted.

## Notes
Habit and reminder data are stored locally in the app. Uninstalling the app clears its local data.
